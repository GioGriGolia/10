package com.example.app1028

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.example.myapplication.R

class MainActivity : AppCompatActivity() {


    private lateinit var tvResult: TextView
    private lateinit var tvClear: TextView
    private var operand = 0.0
    private var operation = ""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvResult = findViewById(R.id.tvResult)
        tvClear = findViewById(R.id.tvResult)
    }


    fun numberClick(clickedView: View) {

        if (clickedView is TextView) {
            var text = tvResult.text.toString()
            val number = clickedView.text.toString()
            if (text == "0") {
                text = ""
            }
            val result = text + number
            tvResult.text = result

        }

        fun operationClick (clickedView: View) {

            if (clickedView is TextView) {

                operand = tvResult.text.toString().toDouble()
                operation = clickedView.text.toString()
                tvResult.text = ""



            }

        }

        fun equalsClick(clickedView: View) {
            val secondOperand = tvResult.text.toString().toDouble()
            when (operation) {
                "+"-> tvResult.text = (operand + secondOperand).toString()
                "-"-> tvResult.text = (operand - secondOperand).toString()
                "*"-> tvResult.text = (operand * secondOperand).toString()
                "/"-> tvResult.text = (operand / secondOperand).toString()


            }


        }



    }
}
